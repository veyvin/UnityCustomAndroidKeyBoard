﻿using UnityEngine;
using System.Collections;
using System.Linq;
using UnityEngine.UI;

public class AndroidPassword : MonoBehaviour {
    string password = null;
    public InputField inputfiled;

    void message(string str)
    {
        Debug.Log(str);
        password += str;
        inputfiled.text = password;
        string xing=null;
        for (int i = 0; i < password.Length; i++)
        {
            xing += "*";
        }

        inputfiled.textComponent.text = xing;
    }
     
}
